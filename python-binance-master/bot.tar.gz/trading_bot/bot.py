# =============================================================
#   BOT — Main trading loop (Multi-Coin Version)
#   Scans the market -> Finds best deal -> Buys -> Monitors
# =============================================================

import sys
import time
import importlib
import requests
from datetime import datetime

from binance.client import Client
from binance.exceptions import BinanceAPIException

import config
import screener
from strategy import get_signal
from risk_manager import RiskManager
from trader import Trader

# -- ANSI Console Colors ---------------------------------------
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
WHITE  = "\033[97m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
RESET  = "\033[0m"


def log(msg: str, color: str = WHITE):
    ts = datetime.now().strftime("%H:%M:%S")
    try:
        print(f"{color}[{ts}]  {msg}{RESET}")
    except UnicodeEncodeError:
        # Fallback to standard text markers if Windows terminal doesn't support emojis (e.g. cp1252)
        clean_msg = (
            msg.replace("🟢", "[BUY]")
               .replace("⚠️", "[WARN]")
               .replace("⛔", "[STOP]")
               .replace("🚨", "[ALERT]")
               .replace("🔍", "[SCAN]")
               .replace("📟", "[INIT]")
               .replace("🏆", "[TOP]")
               .replace("🪙", "[COIN]")
               .replace("📉", "[DOWN]")
               .replace("📈", "[UP]")
               .replace("🚦", "[SIGNAL]")
        )
        try:
            print(f"{color}[{ts}]  {clean_msg}{RESET}")
        except:
            print(f"[{ts}]  {msg.encode('ascii', 'ignore').decode('ascii')}")


def divider(char="-", color=DIM):
    print(f"{color}{char * 60}{RESET}")


def send_telegram(message: str, silent: bool = False):
    token = getattr(config, "TELEGRAM_TOKEN", None)
    chat_id = getattr(config, "TELEGRAM_CHAT_ID", None)
    if not token or not chat_id:
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML",
        "disable_notification": silent
    }
    try:
        requests.post(url, json=payload, timeout=5)
    except Exception as e:
        log(f"⚠️ Telegram notification failed: {e}", RED)


def execute_exit(trader: Trader, base_asset: str, reason: str, entry_price: float):
    divider("=", BOLD)
    log(f">> EXIT TRIGGERED  ->  {reason}", BOLD)
    divider("=", BOLD)

    try:
        current_price = trader.get_current_price()
        pnl_pct = ((current_price - entry_price) / entry_price) * 100

        log(f"Placing MARKET SELL for all {base_asset}...", YELLOW)
        sell_order = trader.sell_all(base_asset)

        log(f"[SELL FILLED]  |  Order ID: {sell_order['orderId']}", GREEN)
        log(f"   Entry Price : {entry_price:.6f} USDT", WHITE)
        log(f"   Exit Price  : {current_price:.6f} USDT", WHITE)

        if pnl_pct >= 0:
            log(f"   Final P&L   : +{pnl_pct:.2f}%  PROFIT", GREEN)
            pnl_text = f"+{pnl_pct:.2f}% PROFIT 🟢"
        else:
            log(f"   Final P&L   : {pnl_pct:.2f}%  LOSS", RED)
            pnl_text = f"{pnl_pct:.2f}% LOSS 🔴"

        time.sleep(2)
        final_usdt = trader.get_balance("USDT")
        log(f"USDT Balance : {final_usdt:.4f} USDT", CYAN)
        
        send_telegram(f"🔔 <b>TRADE CLOSED</b>\n\n<b>Pair:</b> {base_asset}USDT\n<b>Reason:</b> {reason}\n<b>Entry:</b> {entry_price:.6f}\n<b>Exit:</b> {current_price:.6f}\n<b>P&L:</b> {pnl_text}\n<b>Wallet:</b> {final_usdt:.4f} USDT")

    except Exception as e:
        log(f"[SELL FAILED]: {e}", RED)
        log("!! Please manually sell your position on Binance!", RED)
        send_telegram(f"🚨 <b>SELL FAILED!</b>\n\n<b>Pair:</b> {base_asset}USDT\n<b>Error:</b> {e}\n⚠️ Please check Binance manually.")

    divider("=", BOLD)
    log("[BOT STOPPED]", BOLD)


def run_bot():
    divider("=", CYAN)
    print(f"{BOLD}{CYAN}")
    print("   +-------------------------------------------------+")
    print("   |        BINANCE MULTI-COIN SCREENER  v1.2       |")
    print("   |   Scanning Top Coins | Stop Loss | Profit       |")
    print("   +-------------------------------------------------+")
    print(f"{RESET}")
    divider("=", CYAN)

    client = Client(config.API_KEY, config.API_SECRET, testnet=config.TESTNET)
    
    # Fix for Timestamp -1021 error (sync local time with Binance server)
    try:
        server_time = client.get_server_time()
        client.timestamp_offset = server_time['serverTime'] - int(time.time() * 1000)
    except Exception as e:
        log(f"⚠️ Could not sync time with Binance: {e}", RED)

    mode_label = f"{RED}[LIVE TRADING]{RESET}" if not config.TESTNET else f"{GREEN}[TESTNET MODE]{RESET}"
    log(f"Mode     : {mode_label}")
    
    if config.MULTI_COIN:
        log(f"Mode     : {BOLD}MULTI-COIN SCREENER{RESET} (Scanning top {config.SCREENER_LIMIT} pairs)", CYAN)
    else:
        log(f"Mode     : {BOLD}SINGLE COIN{RESET} ({config.SYMBOL})", CYAN)

    log(f"Strategy : RSI({config.RSI_PERIOD}) < {config.RSI_OVERSOLD} + EMA Cross", CYAN)
    log(f"Targets  : TP: +{config.TAKE_PROFIT_PCT}%  |  SL: {config.STOP_LOSS_PCT}%", CYAN)
    divider("-")

    active_symbol = config.SYMBOL
    trader        = None # Will be initialized per coin
    entry_price   = None
    quantity      = None
    risk_mgr      = None
    in_position   = False
    order_list_id = None
    tp_order_id   = None
    sl_order_id   = None

    # ── AUTO-RESTORE ACTIVE OCO POSITION ─────────────────────
    log("Checking for active open trades on Binance...", DIM)
    try:
        open_orders = client.get_open_orders()
        oco_orders = [o for o in open_orders if o.get('orderListId', -1) != -1]
        if oco_orders:
            first_oco = oco_orders[0]
            active_symbol = first_oco['symbol']
            order_list_id = first_oco['orderListId']
            
            # Find base asset and quantity
            base_asset = active_symbol.replace("USDT", "")
            trader = Trader(client, active_symbol)
            quantity = float(first_oco['origQty'])
            
            # Grab individual order IDs
            for o in oco_orders:
                if o['type'] == "LIMIT_MAKER":
                    tp_order_id = o['orderId']
                elif o['type'] == "STOP_LOSS":
                    sl_order_id = o['orderId']
            
            # Fetch entry price from last buy trade history
            try:
                trades = client.get_my_trades(symbol=active_symbol, limit=5)
                buy_trades = [t for t in trades if t.get('isBuyer', False)]
                if buy_trades:
                    entry_price = float(buy_trades[-1]['price'])
                else:
                    entry_price = float(first_oco.get('stopPrice', 0)) / (1 + config.STOP_LOSS_PCT / 100)
            except Exception:
                entry_price = float(first_oco.get('stopPrice', 0)) / (1 + config.STOP_LOSS_PCT / 100)
                
            in_position = True
            risk_mgr = RiskManager(entry_price, config.STOP_LOSS_PCT, config.TAKE_PROFIT_PCT)
            
            log(f"🔄 [RESTORED] Lock-on active position: {active_symbol}!", GREEN)
            log(f"   Entry Price  : {entry_price:.6f} USDT", WHITE)
            log(f"   Quantity     : {quantity} {base_asset}", WHITE)
            log(f"   Stop Loss @  : {risk_mgr.stop_loss_price:.6f}", RED)
            log(f"   Take Profit @: {risk_mgr.take_profit_price:.6f}", GREEN)
            log(f"   OCO List ID  : {order_list_id}", CYAN)
            divider("-")
    except Exception as e:
        log(f"⚠️ Position auto-recovery check failed: {e}", DIM)

    while True:
        try:
            # ── LIVE RELOAD CONFIG ───────────────────────────
            # This allows the bot to pick up changes from config.py and screener.py
            # without needing a restart.
            importlib.reload(config)
            importlib.reload(screener)
            
            # Send a startup notification once to confirm connection
            if 'telegram_notified' not in globals():
                send_telegram("📟 <b>Bot Connected!</b>\nYour mobile notifications are now active.")
                global telegram_notified
                telegram_notified = True
            
            # ── NO POSITION: Scan the market
            if not in_position:
                # Fetch live balance to prove API is working
                temp_trader = Trader(client, "BNBUSDT") 
                usdt_balance = temp_trader.get_balance("USDT")
                log(f"Wallet Balance: {BOLD}{usdt_balance:.4f} USDT{RESET}", CYAN)
                
                if config.MULTI_COIN:
                    log("Scanning market for the best entry...", YELLOW)
                    symbols = screener.get_top_usdt_pairs(client, config.SCREENER_LIMIT)
                    candidates = screener.find_best_entry(client, symbols, config.KLINE_INTERVAL)
                    
                    if not candidates:
                        log("No candidates found. Retrying...", DIM)
                        time.sleep(30)
                        continue
                    
                    # The top candidate is the most oversold (lowest RSI)
                    best = candidates[0]
                    active_symbol = best['symbol']
                    signal = best['signal']
                    rsi = best['rsi']
                    ema_f = best['ema_f']
                    ema_s = best['ema_s']
                    
                    print(f"   [Best Match] {BOLD}{active_symbol}{RESET} | RSI: {rsi:.1f} | EMA{config.EMA_FAST}: {ema_f:.4f} | EMA{config.EMA_SLOW}: {ema_s:.4f} | Signal: {signal}")
                    
                    if getattr(config, "TELEGRAM_SEND_SCANS", False):
                        tg_time = datetime.now().strftime("%H:%M:%S")
                        tg_msg = (
                            f"🔍 <b>Binance Scan Update</b>\n"
                            f"⏳ <b>Time:</b> {tg_time}\n\n"
                            f"🏆 <b>Best Entry Match:</b>\n"
                            f"🪙 <b>Symbol:</b> #{active_symbol}\n"
                            f"📉 <b>RSI:</b> {rsi:.1f}\n"
                            f"📈 <b>EMA {config.EMA_FAST}:</b> {ema_f:.4f}\n"
                            f"📉 <b>EMA {config.EMA_SLOW}:</b> {ema_s:.4f}\n"
                            f"🚦 <b>Signal:</b> {'🟢 BUY SIGNAL' if signal == 'BUY' else '⏳ HOLD'}\n\n"
                            f"💰 <b>Wallet:</b> {usdt_balance:.4f} USDT"
                        )
                        send_telegram(tg_msg, silent=True)
                else:
                    # Single coin mode
                    active_symbol = config.SYMBOL
                    signal, rsi, ema_f, ema_s = get_signal(
                        client, active_symbol, config.KLINE_INTERVAL,
                        config.RSI_PERIOD, config.EMA_FAST, config.EMA_SLOW, config.RSI_OVERSOLD
                    )
                    now = datetime.now().strftime("%H:%M:%S")
                    print(f"{DIM}[{now}]{RESET} {active_symbol} | RSI: {rsi:.1f} | Signal: {signal}")

                    if getattr(config, "TELEGRAM_SEND_SCANS", False):
                        tg_msg = (
                            f"🔍 <b>Binance Single Scan</b>\n"
                            f"⏳ <b>Time:</b> {now}\n\n"
                            f"🪙 <b>Symbol:</b> #{active_symbol}\n"
                            f"📉 <b>RSI:</b> {rsi:.1f}\n"
                            f"📈 <b>EMA {config.EMA_FAST}:</b> {ema_f:.4f}\n"
                            f"📉 <b>EMA {config.EMA_SLOW}:</b> {ema_s:.4f}\n"
                            f"🚦 <b>Signal:</b> {'🟢 BUY SIGNAL' if signal == 'BUY' else '⏳ HOLD'}\n\n"
                            f"💰 <b>Wallet:</b> {usdt_balance:.4f} USDT"
                        )
                        send_telegram(tg_msg, silent=True)

                if signal == "BUY":
                    divider("-")
                    log(f"🟢 BUY SIGNAL on {active_symbol}! Executing...", GREEN)
                    
                    trader = Trader(client, active_symbol)
                    usdt_balance = trader.get_balance("USDT")
                    trade_amount = round(usdt_balance * (config.TRADE_AMOUNT_PCT / 100), 4)

                    # ── STEP 1: Execute the market BUY ───────────────────
                    buy_ok = False
                    try:
                        order, entry_price, quantity = trader.buy_market(trade_amount)
                        base_asset = active_symbol.replace("USDT", "")
                        log(f"[BUY FILLED]   |  {active_symbol}", GREEN)
                        log(f"   Entry Price  : {entry_price:.6f} USDT", WHITE)
                        log(f"   Quantity     : {quantity} {base_asset}", WHITE)
                        buy_ok = True

                        # ── IMMEDIATELY mark in_position = True ──────────
                        # This ensures the bot NEVER forgets it bought a coin,
                        # even if the OCO placement step below fails.
                        in_position = True
                        risk_mgr    = RiskManager(entry_price, config.STOP_LOSS_PCT, config.TAKE_PROFIT_PCT)
                        order_list_id = None
                        tp_order_id   = None
                        sl_order_id   = None

                    except Exception as e:
                        log(f"[BUY FAILED]: {e}", RED)
                        send_telegram(f"🚨 <b>BUY FAILED</b>\n\n<b>Pair:</b> {active_symbol}\n<b>Error:</b> {e}")

                    # ── STEP 2: Place OCO (only if buy succeeded) ─────────
                    if buy_ok:
                        take_profit_price = entry_price * (1 + config.TAKE_PROFIT_PCT / 100)
                        stop_loss_price   = entry_price * (1 + config.STOP_LOSS_PCT / 100)

                        # Retry OCO up to 3 times in case of transient errors
                        oco_placed = False
                        for attempt in range(1, 4):
                            try:
                                log(f"Placing OCO order... (attempt {attempt}/3)", YELLOW)
                                oco_order     = trader.place_oco_order(quantity, take_profit_price, stop_loss_price)
                                order_list_id = oco_order["orderListId"]
                                oco_placed    = True

                                # Grab TP/SL order IDs from response or open orders
                                tp_order_id = None
                                sl_order_id = None
                                order_entries = oco_order.get("orderReports") or oco_order.get("orders") or []
                                for o in order_entries:
                                    otype = o.get("type", "")
                                    if otype == "LIMIT_MAKER":
                                        tp_order_id = o["orderId"]
                                    elif otype in ["STOP_LOSS", "STOP_LOSS_LIMIT"]:
                                        sl_order_id = o["orderId"]

                                # Fallback: fetch from open orders if types missing
                                if tp_order_id is None or sl_order_id is None:
                                    time.sleep(1)
                                    open_ords = client.get_open_orders(symbol=active_symbol)
                                    for o in open_ords:
                                        if o.get("orderListId") == order_list_id:
                                            otype = o.get("type", "")
                                            if otype == "LIMIT_MAKER":
                                                tp_order_id = o["orderId"]
                                            elif otype in ["STOP_LOSS", "STOP_LOSS_LIMIT"]:
                                                sl_order_id = o["orderId"]

                                log(f"   Stop Loss @  : {risk_mgr.stop_loss_price:.6f}", RED)
                                log(f"   Take Profit @: {risk_mgr.take_profit_price:.6f}", GREEN)
                                log(f"   OCO List ID  : {order_list_id}", CYAN)
                                send_telegram(f"🚀 <b>BUY FILLED (OCO ACTIVE)</b>\n\n<b>Pair:</b> {active_symbol}\n<b>Price:</b> {entry_price:.6f}\n<b>TP:</b> {risk_mgr.take_profit_price:.6f}\n<b>SL:</b> {risk_mgr.stop_loss_price:.6f}")
                                divider("-")
                                log(f"Monitoring {active_symbol} OCO exit...", CYAN)
                                break  # OCO placed successfully, stop retrying

                            except Exception as oco_err:
                                log(f"[OCO attempt {attempt} FAILED]: {oco_err}", RED)
                                if attempt < 3:
                                    log("Retrying OCO in 3 seconds...", YELLOW)
                                    time.sleep(3)

                        if not oco_placed:
                            # OCO failed all 3 attempts — bot stays IN POSITION
                            # and will monitor price manually via RiskManager
                            log("[WARN] OCO could not be placed. Bot will monitor manually using Stop Loss / Take Profit targets.", RED)
                            send_telegram(f"🚨 <b>OCO FAILED (Manual Monitor Active)</b>\n\n<b>Pair:</b> {active_symbol}\n<b>Price:</b> {entry_price:.6f}\n<b>TP:</b> {risk_mgr.take_profit_price:.6f}\n<b>SL:</b> {risk_mgr.stop_loss_price:.6f}\n\n⚠️ Bot is monitoring manually. No exchange-side protection!")
                
                time.sleep(config.SIGNAL_SCAN_SEC)

            # ── IN POSITION: monitor OCO status
            else:
                current_price = trader.get_current_price()
                pnl_pct    = risk_mgr.get_pnl_pct(current_price)
                now        = datetime.now().strftime("%H:%M:%S")

                pnl_color = GREEN if pnl_pct >= 0 else RED
                print(f"{DIM}[{now}]{RESET} {active_symbol} | P&L: {pnl_color}{pnl_pct:+.3f}%{RESET} | Price: {current_price:.6f}")

                # ── SEND LIVE P&L CARD TO TELEGRAM (SILENT MONITORING)
                try:
                    pnl_text = f"+{pnl_pct:.3f}%" if pnl_pct >= 0 else f"{pnl_pct:.3f}%"
                    pnl_emoji = "🟢" if pnl_pct >= 0 else "🔴"
                    tg_msg = (
                        f"📈 <b>Live Position Monitor</b>\n"
                        f"🪙 <b>Pair:</b> #{active_symbol}\n"
                        f"💰 <b>Current Price:</b> {current_price:.6f} USDT\n"
                        f"📉 <b>Entry Price:</b> {entry_price:.6f} USDT\n"
                        f"🚦 <b>Current P&L:</b> {pnl_emoji} <b>{pnl_text}</b>\n\n"
                        f"🎯 <b>TP Target (+{config.TAKE_PROFIT_PCT}%):</b> {risk_mgr.take_profit_price:.6f}\n"
                        f"🛡️ <b>SL Target ({config.STOP_LOSS_PCT}%):</b> {risk_mgr.stop_loss_price:.6f}"
                    )
                    send_telegram(tg_msg, silent=True)
                except Exception as tg_err:
                    pass

                # Check OCO status on Binance using correct API method
                try:
                    status_info = client.v3_get_order_list(orderListId=order_list_id)
                    list_status = status_info.get("listOrderStatus", "EXECUTING")
                except Exception as e:
                    # Fallback: check if OCO orders are still in open orders
                    try:
                        open_orders = client.get_open_orders()
                        has_oco = any(o.get('orderListId') == order_list_id for o in open_orders)
                        if not has_oco:
                            list_status = "ALL_DONE"
                        else:
                            list_status = "EXECUTING"
                    except Exception as fallback_err:
                        list_status = "EXECUTING"
                        log(f"⚠️ OCO status check failed: {fallback_err}. Retrying next loop...", YELLOW)

                if list_status == "ALL_DONE":
                    log("Exit order filled! Checking OCO results...", GREEN)
                    reason = "UNKNOWN"
                    exit_price = current_price
                    
                    try:
                        tp_order = client.get_order(symbol=active_symbol, orderId=tp_order_id)
                        sl_order = client.get_order(symbol=active_symbol, orderId=sl_order_id)
                        
                        if tp_order["status"] == "FILLED":
                            reason = "TAKE_PROFIT"
                            exit_price = float(tp_order["price"])
                        elif sl_order["status"] == "FILLED":
                            reason = "STOP_LOSS"
                            exec_qty = float(sl_order.get("executedQty", 0))
                            cum_quote = float(sl_order.get("cummulativeQuoteQty", 0))
                            if exec_qty > 0:
                                exit_price = cum_quote / exec_qty
                            else:
                                exit_price = float(sl_order.get("price", current_price))
                                if exit_price == 0:
                                    exit_price = float(sl_order.get("stopPrice", current_price))
                    except Exception as e:
                        log(f"Could not fetch OCO fill details: {e}", DIM)

                    pnl_pct = ((exit_price - entry_price) / entry_price) * 100
                    pnl_text = f"+{pnl_pct:.2f}% PROFIT 🟢" if pnl_pct >= 0 else f"{pnl_pct:.2f}% LOSS 🔴"

                    divider("=", BOLD)
                    log(f">> EXIT TRIGGERED (OCO)  ->  {reason}", BOLD)
                    divider("=", BOLD)

                    log(f"[OCO EXITED]  |  Target Hit: {reason}", GREEN if pnl_pct >= 0 else RED)
                    log(f"   Entry Price : {entry_price:.6f} USDT", WHITE)
                    log(f"   Exit Price  : {exit_price:.6f} USDT", WHITE)

                    if pnl_pct >= 0:
                        log(f"   Final P&L   : +{pnl_pct:.2f}%  PROFIT", GREEN)
                    else:
                        log(f"   Final P&L   : {pnl_pct:.2f}%  LOSS", RED)

                    time.sleep(2)
                    final_usdt = trader.get_balance("USDT")
                    log(f"USDT Balance : {final_usdt:.4f} USDT", CYAN)

                    send_telegram(f"🔔 <b>TRADE CLOSED (OCO)</b>\n\n<b>Pair:</b> {base_asset}USDT\n<b>Reason:</b> {reason}\n<b>Entry:</b> {entry_price:.6f}\n<b>Exit:</b> {exit_price:.6f}\n<b>P&L:</b> {pnl_text}\n<b>Wallet:</b> {final_usdt:.4f} USDT")

                    in_position = False
                    log("Returning to scanning mode...", YELLOW)
                    divider("-")
                else:
                    # Double check if base asset is gone (e.g. manually sold or cancelled)
                    try:
                        account = client.get_account()
                        base_bal = 0.0
                        for b in account["balances"]:
                            if b["asset"] == base_asset:
                                base_bal = float(b["free"]) + float(b["locked"])
                                break
                        if base_bal < trader.min_qty:
                            log("⚠️ Base asset balance is gone! The trade appears to have been closed externally.", YELLOW)
                            try:
                                client.cancel_order_list(symbol=active_symbol, orderListId=order_list_id)
                                log("Cancelled remaining OCO orders.", DIM)
                            except:
                                pass
                            in_position = False
                            log("Returning to scanning mode...", YELLOW)
                            divider("-")
                    except Exception as e:
                        log(f"⚠️ Balance check failed: {e}", DIM)

                time.sleep(config.CHECK_INTERVAL_SEC)

        except KeyboardInterrupt:
            log("\n⛔ Stopped by user.", YELLOW)
            if in_position:
                base_asset = active_symbol.replace("USDT", "")
                try:
                    log("Cancelling active OCO order...", YELLOW)
                    client.cancel_order_list(symbol=active_symbol, orderListId=order_list_id)
                except Exception as e:
                    log(f"Could not cancel OCO: {e}", DIM)
                execute_exit(trader, base_asset, "MANUAL STOP", entry_price)
            send_telegram("⛔ <b>Bot Stopped</b>\nThe trading bot was manually stopped by the user.")
            break
        except Exception as e:
            log(f"⚠️ Error: {e}", YELLOW)
            send_telegram(f"⚠️ <b>Bot Error</b>\nAn error occurred: {e}\nRetrying in 15 seconds...")
            time.sleep(15)

if __name__ == "__main__":
    run_bot()
