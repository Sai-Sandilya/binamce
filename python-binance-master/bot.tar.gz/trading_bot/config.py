# =============================================================
#   BINANCE AUTO TRADING BOT — CONFIGURATION
#   Edit this file with your credentials and preferences.
# =============================================================

# ── TELEGRAM NOTIFICATIONS ───────────────────────────────────
TELEGRAM_TOKEN   = "8805539695:AAH5rMh9WE6rNcv1GSfFyGjSF9q6BxcM15g"
TELEGRAM_CHAT_ID = "895876593"
TELEGRAM_SEND_SCANS = False  # Set to True to receive scan results on Telegram every cycle


# ── API CREDENTIALS ──────────────────────────────────────────
# Get testnet keys from: https://testnet.binance.vision/
# Get live keys from:    https://www.binance.com/en/my/settings/api-management
API_KEY    = "rliFZGjz2VzypIw7PHpvgSTHg0KZLfq5koKF0uJyUC6damJDhuMTSu3Zpndb46G4"
API_SECRET = "OjbxwIshJbCj2yYinpHLrZLi5Q1jQc8iIbFdeB7ICrcyiFaQM3vwev8n0WeJQ3Mb"

# ── MODE ─────────────────────────────────────────────────────
TESTNET = False   # ← ALWAYS start with True. Set False only for live trading.
BOT_MODE = "SCREENER"  # Options: "SCREENER" (RSI/EMA bot) or "GRID" (Grid trading bot)

# ── TRADING PAIR ─────────────────────────────────────────────
# Options: "BNBUSDT", "BTCUSDT", etc. (Only used if MULTI_COIN = False)
SYMBOL = "BTCUSDT"

# ── MULTI-COIN SCANNER ───────────────────────────────────────
MULTI_COIN     = True    # If True, bot scans many coins. If False, it only trades SYMBOL above.
SCREENER_LIMIT = 20      # How many of the top volume coins to scan (20 is highly focused and fast)
COIN_BLACKLIST = ["LUNCUSDT", "LUNAUSDT", "USTCUSDT"]  # Exclude highly volatile/collapsed tokens
MIN_PRICE      = 1.0    # Exclude all coins trading below $1.00

# ── TRADE AMOUNT ─────────────────────────────────────────────
# Percentage of your available USDT balance to use (e.g. 95 = 95%)
# Keeping a small % free avoids "insufficient balance" errors due to fees.
TRADE_AMOUNT_PCT = 95  # %

# ── RISK MANAGEMENT ──────────────────────────────────────────
STOP_LOSS_PCT   = -0.8   # Tight stop loss
TAKE_PROFIT_PCT = 0.8    # Quick profit taking

# ── STRATEGY SETTINGS ────────────────────────────────────────
KLINE_INTERVAL = "1m"    # Candle interval: 1m, 3m, 5m, 15m, 30m, 1h

RSI_PERIOD    = 14       # RSI lookback period
RSI_OVERSOLD  = 40       # RSI below this → BUY signal (Optimized via backtesting)
RSI_OVERBOUGHT = 65      # RSI above this → considered overbought

EMA_FAST = 7             # Fast EMA period
EMA_SLOW = 25            # Slow EMA period


# ── TIMING ───────────────────────────────────────────────────
CHECK_INTERVAL_SEC = 10  # Check active trades every 10 seconds
SIGNAL_SCAN_SEC    = 15  # Scan for new opportunities every 15 seconds

# ── SPOT GRID SETTINGS ───────────────────────────────────────
# Only used if BOT_MODE = "GRID"
GRID_SYMBOL      = "BNBUSDT"  # The coin to run the grid on
GRID_LOWER_LIMIT = 635.0      # Bottom of the grid range (in USDT)
GRID_UPPER_LIMIT = 665.0      # Top of the grid range (in USDT)
GRID_LEVELS      = 5          # Number of grid buy/sell levels (minimum 2)
GRID_AMOUNT_USDT = 15.0       # USDT size per grid level (minimum is 10.0 USDT)
GRID_POLL_SEC    = 10         # How often to check active grid orders (seconds)

