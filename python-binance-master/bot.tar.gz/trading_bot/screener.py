# =============================================================
#   SCREENER — Scans the market for the best trading pairs
# =============================================================

def get_top_usdt_pairs(client, limit=50):
    """
    Fetch all USDT pairs from Binance, filter by volume, 
    and return the top most liquid ones.
    """
    tickers = client.get_ticker()
    
    # Filter for USDT pairs and sort by 24h Volume
    import config
    blacklist = getattr(config, "COIN_BLACKLIST", [])
    
    usdt_pairs = []
    for t in tickers:
        symbol = t['symbol']
        if symbol in blacklist:
            continue
        
        # Exclude micro-penny/zombie coins trading below our threshold
        price = float(t.get('lastPrice', 0))
        min_price = getattr(config, "MIN_PRICE", 0.0)
        if price < min_price:
            continue
            
        # Only look at USDT pairs, avoid stablecoins, fiat, and gold/silver pegged tokens
        avoid_keywords = [
            'USDC', 'FDUSD', 'TUSD', 'DAI', 'USDP', 'BUSD', 'EUR', 'GBP', 
            'TRY', 'BRL', 'RUB', 'ZAR', 'UAH', 'NGN', 'PAXG', 'XAUT'
        ]
        is_stable_or_fiat = any(x in symbol for x in avoid_keywords)
        if symbol.endswith('USDT') and not is_stable_or_fiat and 'UP' not in symbol and 'DOWN' not in symbol:
            usdt_pairs.append({
                'symbol': symbol,
                'volume': float(t['quoteVolume']),
                'change': float(t['priceChangePercent'])
            })
    
    # Sort by volume (descending) and take the top 50
    usdt_pairs.sort(key=lambda x: x['volume'], reverse=True)
    return [p['symbol'] for p in usdt_pairs[:limit]]




def find_best_entry(client, symbols, interval):
    """
    Scan a list of symbols and find the one with the lowest RSI (most oversold).
    """
    from strategy import get_signal
    import config
    
    candidates = []
    
    print(f"   [Screener] Scanning {len(symbols)} coins...")
    
    for symbol in symbols:
        try:
            # We use a fast signal check
            signal, rsi, ema_f, ema_s = get_signal(
                client, symbol, interval, 
                config.RSI_PERIOD, config.EMA_FAST, config.EMA_SLOW,
                config.RSI_OVERSOLD
            )
            
            if rsi is not None:
                candidates.append({
                    'symbol': symbol,
                    'rsi': rsi,
                    'signal': signal,
                    'ema_f': ema_f,
                    'ema_s': ema_s
                })
        except:
            continue # Skip coins with issues (e.g. new listings with no history)

    # Sort candidates by RSI (lowest first = most oversold)
    candidates.sort(key=lambda x: x['rsi'])
    
    return candidates
