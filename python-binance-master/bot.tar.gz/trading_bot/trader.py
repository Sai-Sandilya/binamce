# =============================================================
#   TRADER — Handles all Binance order execution
# =============================================================

import math
from binance.client import Client
from binance.exceptions import BinanceAPIException


class Trader:
    def __init__(self, client: Client, symbol: str):
        self.client = client
        self.symbol = symbol
        self._load_symbol_filters()

    # ── Symbol Info ───────────────────────────────────────────
    def _load_symbol_filters(self):
        """Load LOT_SIZE, PRICE_FILTER and MIN_NOTIONAL filters from Binance."""
        info = self.client.get_symbol_info(self.symbol)
        self.step_size    = 1.0
        self.min_qty      = 0.0
        self.min_notional = 10.0
        self.tick_size    = 0.00000001

        for f in info["filters"]:
            if f["filterType"] == "LOT_SIZE":
                self.step_size = float(f["stepSize"])
                self.min_qty   = float(f["minQty"])
            if f["filterType"] in ("MIN_NOTIONAL", "NOTIONAL"):
                self.min_notional = float(f.get("minNotional", f.get("minNotional", 10)))
            if f["filterType"] == "PRICE_FILTER":
                self.tick_size = float(f["tickSize"])

    def _round_qty(self, qty: float) -> float:
        """Floor qty to the allowed step size precision."""
        if self.step_size == 0:
            return qty
        step_str = f"{self.step_size:.8f}".rstrip('0')
        precision = len(step_str.split('.')[1]) if '.' in step_str else 0
        rounded = math.floor(qty / self.step_size) * self.step_size
        return round(rounded, precision)

    def _round_price(self, price: float) -> float:
        """Round price to the allowed tick size precision."""
        if self.tick_size == 0:
            return price
        tick_str = f"{self.tick_size:.8f}".rstrip('0')
        precision = len(tick_str.split('.')[1]) if '.' in tick_str else 0
        rounded = math.floor(price / self.tick_size) * self.tick_size
        return round(rounded, precision)


    # ── Price & Balance ───────────────────────────────────────
    def get_current_price(self) -> float:
        """Fetch live market price for the symbol."""
        ticker = self.client.get_symbol_ticker(symbol=self.symbol)
        return float(ticker["price"])

    def get_balance(self, asset: str) -> float:
        """Return free (spendable) balance for a given asset."""
        account = self.client.get_account()
        for b in account["balances"]:
            if b["asset"] == asset:
                return float(b["free"])
        return 0.0

    # ── Orders ───────────────────────────────────────────────
    def buy_market(self, usdt_amount: float):
        """
        Place a market BUY order using a USDT amount.

        Returns:
            order (dict)       : Binance order response
            entry_price (float): Estimated fill price
            quantity (float)   : Quantity purchased
        """
        price    = self.get_current_price()
        qty      = self._round_qty(usdt_amount / price)

        if qty < self.min_qty:
            raise ValueError(
                f"Calculated quantity {qty} is below Binance minimum {self.min_qty}. "
                f"Increase your USDT trade amount."
            )

        notional = qty * price
        if notional < self.min_notional:
            raise ValueError(
                f"Order notional {notional:.2f} USDT is below minimum {self.min_notional} USDT."
            )

        order = self.client.create_order(
            symbol   = self.symbol,
            side     = Client.SIDE_BUY,
            type     = Client.ORDER_TYPE_MARKET,
            quantity = qty,
        )
        return order, price, qty

    def sell_all(self, asset: str):
        """
        Sell the entire free balance of an asset.

        Returns:
            order (dict): Binance order response
        """
        balance = self.get_balance(asset)
        qty     = self._round_qty(balance)

        if qty <= 0 or qty < self.min_qty:
            raise ValueError(
                f"Sell failed: free balance is {balance} {asset}, "
                f"minimum sellable is {self.min_qty}."
            )

        order = self.client.create_order(
            symbol   = self.symbol,
            side     = Client.SIDE_SELL,
            type     = Client.ORDER_TYPE_MARKET,
            quantity = qty,
        )
        return order

    def place_oco_order(self, quantity: float, take_profit_price: float, stop_loss_price: float):
        """
        Place a Sell OCO order using the new Binance API v3 format.
        Above order = LIMIT_MAKER (Take Profit)
        Below order = STOP_LOSS (Stop Loss)
        Uses direct _request_api call to POST /api/v3/orderList/oco
        """
        qty = self._round_qty(quantity)
        tp_price = self._round_price(take_profit_price)
        sl_price = self._round_price(stop_loss_price)

        precision = max(0, int(round(-math.log(self.tick_size, 10), 0)))
        tp_price_str = f"{tp_price:.{precision}f}"
        sl_price_str = f"{sl_price:.{precision}f}"

        params = {
            "symbol":         self.symbol,
            "side":           "SELL",
            "quantity":       str(qty),
            "aboveType":      "LIMIT_MAKER",
            "abovePrice":     tp_price_str,
            "belowType":      "STOP_LOSS",
            "belowStopPrice": sl_price_str,
        }
        # Use direct API call since auto-generated wrapper may not exist
        return self.client._request_api("post", "orderList/oco", signed=True, data=params, version="v3")

