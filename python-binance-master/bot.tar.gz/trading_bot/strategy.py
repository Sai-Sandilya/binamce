# =============================================================
#   STRATEGY — RSI + EMA Crossover Signal Generator
#   Returns BUY / HOLD signal based on technical indicators.
# =============================================================

def calculate_rsi(closes, period=14):
    """
    Calculate Relative Strength Index (RSI).
    Returns float 0-100, or None if not enough data.
    """
    if len(closes) < period + 1:
        return None

    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains  = [d if d > 0 else 0.0 for d in deltas]
    losses = [-d if d < 0 else 0.0 for d in deltas]

    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period

    for i in range(period, len(deltas)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    if avg_loss == 0:
        return 100.0

    rs = avg_gain / avg_loss
    return round(100 - (100 / (1 + rs)), 2)


def calculate_ema(closes, period):
    """
    Calculate Exponential Moving Average (EMA).
    Returns float or None if not enough data.
    """
    if len(closes) < period:
        return None

    k   = 2 / (period + 1)
    ema = sum(closes[:period]) / period  # seed with SMA

    for price in closes[period:]:
        ema = price * k + ema * (1 - k)

    return round(ema, 6)


def get_signal(client, symbol, interval,
               rsi_period=14, ema_fast=9, ema_slow=21, rsi_oversold=35):
    """
    Fetch latest candles and compute trading signal.

    Returns:
        signal (str)  : 'BUY' or 'HOLD'
        rsi    (float): current RSI value
        ema_f  (float): fast EMA value
        ema_s  (float): slow EMA value
    """
    # Fetch enough candles for indicator warmup
    klines = client.get_klines(symbol=symbol, interval=interval, limit=150)
    closes = [float(k[4]) for k in klines][:-1]  # Exclude the current open candle to use closed candles only

    rsi   = calculate_rsi(closes, rsi_period)
    ema_f = calculate_ema(closes, ema_fast)
    ema_s = calculate_ema(closes, ema_slow)

    # Fallback if indicators aren't ready
    if rsi is None or ema_f is None or ema_s is None:
        return 'HOLD', rsi, ema_f, ema_s

    # BUY condition: RSI oversold AND fast EMA above slow EMA (upward momentum)
    if rsi < rsi_oversold and ema_f > ema_s:
        return 'BUY', rsi, ema_f, ema_s

    return 'HOLD', rsi, ema_f, ema_s
